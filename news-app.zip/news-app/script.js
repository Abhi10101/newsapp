


const populateNews = (articles) => {
  articles.forEach((news) => {
    let template = `
        <div class="card bg-light mb-3" style="max-width: 20rem; margin: 10px">
          <div class="card-header">${news.title}</div>
          <div class="card-body">
            <p class="card-text">
              ${news.content}
              <br>
              <a href="${news.url}">Read More</a>
            </p>
          </div>
          <div class="card-footer">
            Source: ${news.source.name}
          </div>
        </div>
    `;
    $("#news").append(template);
  });
};

$(document).ready(() => {
  $.get(
    "https://newsapi.org/v2/top-headlines?country=in&apiKey=67c64e1f461044c184fef1250283f8e6",
    (resp) => {
      populateNews(resp.articles);
    }
  );
});
